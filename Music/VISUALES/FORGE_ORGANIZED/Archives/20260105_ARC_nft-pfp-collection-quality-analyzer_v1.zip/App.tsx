
import React, { useState, useCallback } from 'react';
import FileUpload from './components/FileUpload';
import AnalysisReport from './components/AnalysisReport';
import Loader from './components/Loader';
import { analyzePsdFile, CollectionAttributes } from './services/geminiService';
import { GithubIcon } from './components/icons/GithubIcon';

const App: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    setAnalysis(null);
    setError(null);
  };

  const handleAnalyze = useCallback(async (attributes: CollectionAttributes) => {
    if (!file) {
      setError('Please select a file first.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);

    try {
      const result = await analyzePsdFile(file.name, file.size, attributes);
      setAnalysis(result);
    } catch (e) {
      console.error(e);
      setError('An error occurred during analysis. Please check the console and ensure your API key is set up correctly.');
    } finally {
      setIsLoading(false);
    }
  }, [file]);

  const handleReset = () => {
    setFile(null);
    setAnalysis(null);
    setError(null);
    setIsLoading(false);
  };

  return (
    <div className="bg-gray-900 min-h-screen text-white flex flex-col items-center p-4 sm:p-6 md:p-8 font-sans">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-8">
            <div className="flex justify-center items-center gap-4 mb-2">
                 <h1 className="text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-600">
                    NFT PFP Analyzer AI
                 </h1>
            </div>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Upload your collection's .PSD file and provide some details to get an AI-powered quality assessment.
          </p>
        </header>

        <main className="w-full">
          {!analysis && !isLoading && (
            <FileUpload onFileSelect={handleFileSelect} onAnalyze={handleAnalyze} selectedFile={file} />
          )}
          
          {isLoading && <Loader />}

          {error && (
            <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">
              <p className="font-bold">Analysis Failed</p>
              <p>{error}</p>
            </div>
          )}

          {analysis && (
            <AnalysisReport report={analysis} onReset={handleReset} />
          )}
        </main>
      </div>
      <footer className="w-full max-w-4xl mx-auto text-center text-gray-500 mt-12 pb-4">
        <p>Powered by Google Gemini</p>
        <a href="https://github.com/google/genai-js" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 hover:text-gray-300 transition-colors">
          <GithubIcon className="w-4 h-4" />
          View on GitHub
        </a>
      </footer>
    </div>
  );
};

export default App;
