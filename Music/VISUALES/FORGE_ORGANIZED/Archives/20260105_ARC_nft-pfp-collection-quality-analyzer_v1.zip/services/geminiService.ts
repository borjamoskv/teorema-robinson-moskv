
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const model = "gemini-3-pro-preview";

export interface CollectionAttributes {
  collectionName: string;
  description: string;
  targetAudience: string;
  traitCount: string;
  supply: string;
}

export const analyzePsdFile = async (
  fileName: string,
  fileSize: number,
  attributes: CollectionAttributes
): Promise<string> => {
  const fileSizeInMB = (fileSize / (1024 * 1024)).toFixed(2);
  const prompt = `
    Eres un asesor de colecciones NFT de clase mundial con gran experiencia en arte digital, marketing y creación de comunidades. Un usuario ha subido un archivo .PSD y ha proporcionado los siguientes detalles sobre su proyecto:

    **Detalles del Proyecto:**
    *   **Archivo PSD:** "${fileName}" (${fileSizeInMB} MB)
    *   **Nombre de la Colección:** ${attributes.collectionName || 'No proporcionado'}
    *   **Descripción/Lore:** ${attributes.description || 'No proporcionado'}
    *   **Público Objetivo:** ${attributes.targetAudience || 'No proporcionado'}
    *   **Cantidad de Categorías de Rasgos:** ${attributes.traitCount || 'No proporcionado'}
    *   **Suministro Total de la Colección:** ${attributes.supply || 'No proporcionado'}

    Basándote en esta información, realiza un análisis de calidad exhaustivo de esta colección de NFT PFP. Aunque no puedes ver el contenido del archivo, actúa como si hubieras analizado sus capas y estructura, utilizando los detalles proporcionados para informar tu evaluación. Proporciona un informe detallado en formato Markdown.

    El informe debe ser profesional, perspicaz y accionable. Utiliza un tono de experto.

    El informe debe incluir las siguientes secciones, claramente marcadas con encabezados de Markdown:

    ### 🎨 Estilo de Arte y Cohesión
    Analiza el estilo de arte potencial. Basándote en el **Nombre**, **Descripción** y **Público Objetivo**, ¿es el concepto único, comercialmente viable y cohesivo? ¿Cómo podría el estilo de arte resonar (o no) con la audiencia prevista?

    ### ✨ Variedad de Rasgos y Sistema de Rareza
    Evalúa el sistema de rasgos basándote en la **Cantidad de Rasgos** y el **Suministro Total**. ¿Es probable que ${attributes.traitCount || 'un número no especificado de'} categorías de rasgos sean suficientes para crear variedad y escasez en una colección de ${attributes.supply || 'un tamaño no especificado'}? Discute la importancia de una estructura de capas bien organizada para lograr esto.

    ### 🖼️ Composición y Legibilidad
    Evalúa cómo se vería el PFP en tamaños pequeños (avatares de redes sociales). ¿La silueta es fuerte? ¿Es legible el sujeto principal? ¿El concepto descrito se presta a un diseño claro y reconocible?

    ### 💡 Originalidad y Ajuste al Mercado
    Considerando la **Descripción** y el **Público Objetivo**, ¿cómo podría esta colección destacarse en el concurrido mercado de NFTs? ¿Qué elementos del concepto la hacen única? ¿Existe una clara propuesta de valor?

    ### 🚀 Potencial de Marketing y Comunidad
    Basándote en todo el brief del proyecto, ¿cuál es el potencial para construir una comunidad sólida? ¿El **Lore** y el arte se prestan a la creación de memes, una narrativa atractiva y una identidad de marca fuerte que atraiga al **Público Objetivo**?

    ### actionable-advice
    Proporciona 3-5 consejos concretos y accionables para que el creador mejore la colección antes del lanzamiento. Estos deben basarse DIRECTAMENTE en la información proporcionada (o en su ausencia). Sé directo, claro y específico.

    ### 🏆 Veredicto Final y Puntuación
    Ofrece un resumen conciso de tu análisis y una puntuación general sobre 10. Justifica la puntuación basándote en la coherencia y el potencial del proyecto tal como se describe en el brief.

    Formatea la respuesta SÓLO en Markdown. Comienza directamente con el primer encabezado. No incluyas ningún texto introductorio antes de la sección "Estilo de Arte y Cohesión".
    `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    
    if (response.text) {
      return response.text;
    } else {
      throw new Error("Received an empty response from the API.");
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get analysis from Gemini API.");
  }
};
