
import React, { useState, useRef, useCallback } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { PsdFileIcon } from './icons/PsdFileIcon';
import { CollectionAttributes } from '../services/geminiService';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onAnalyze: (attributes: CollectionAttributes) => void;
  selectedFile: File | null;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, onAnalyze, selectedFile }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [collectionName, setCollectionName] = useState('');
  const [description, setDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [traitCount, setTraitCount] = useState('');
  const [supply, setSupply] = useState('');

  const handleDrag = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.psd')) {
        onFileSelect(file);
      } else {
        alert('Please upload a .psd file.');
      }
    }
  }, [onFileSelect]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
       const file = e.target.files[0];
       if (file.name.endsWith('.psd')) {
        onFileSelect(file);
      } else {
        alert('Please upload a .psd file.');
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleAnalyzeClick = () => {
    onAnalyze({
        collectionName,
        description,
        targetAudience,
        traitCount,
        supply
    });
  }

  return (
    <div className="w-full p-6 bg-gray-800/50 border-2 border-dashed border-gray-600 rounded-xl text-center transition-all duration-300 ease-in-out hover:border-indigo-500 hover:bg-gray-800">
      {!selectedFile ? (
        <div 
          className={`w-full h-64 flex flex-col justify-center items-center cursor-pointer ${isDragging ? 'bg-indigo-900/50' : ''}`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={handleClick}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".psd"
            onChange={handleFileChange}
            className="hidden"
          />
          <UploadIcon className="w-16 h-16 text-gray-500 mb-4" />
          <p className="text-lg font-semibold text-gray-300">
            <span className="text-indigo-400">Click to upload</span> or drag and drop
          </p>
          <p className="text-gray-500">a .PSD file</p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-4">
          <PsdFileIcon className="w-16 h-16 text-indigo-400 mb-2" />
          <p className="text-lg font-semibold text-gray-200">{selectedFile.name}</p>
          <p className="text-sm text-gray-400">
            (${(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)
          </p>
          
          <div className="w-full max-w-lg mx-auto text-left space-y-4 my-6">
            <div>
                <label htmlFor="collectionName" className="block text-sm font-medium text-gray-300 mb-1">Collection Name</label>
                <input type="text" id="collectionName" value={collectionName} onChange={e => setCollectionName(e.target.value)} className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="e.g., Cyber Punks" />
            </div>
             <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-1">Description & Lore</label>
                <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="A brief story behind your collection..."></textarea>
            </div>
             <div>
                <label htmlFor="targetAudience" className="block text-sm font-medium text-gray-300 mb-1">Target Audience</label>
                <input type="text" id="targetAudience" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="e.g., Art collectors, tech enthusiasts" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                 <div>
                    <label htmlFor="traitCount" className="block text-sm font-medium text-gray-300 mb-1">Trait Categories</label>
                    <input type="number" id="traitCount" value={traitCount} onChange={e => setTraitCount(e.target.value)} className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="e.g., 8" />
                </div>
                 <div>
                    <label htmlFor="supply" className="block text-sm font-medium text-gray-300 mb-1">Total Supply</label>
                    <input type="number" id="supply" value={supply} onChange={e => setSupply(e.target.value)} className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="e.g., 10000" />
                </div>
            </div>
          </div>

          <button
            onClick={handleAnalyzeClick}
            className="px-8 py-3 bg-indigo-600 rounded-lg font-semibold text-white hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition-transform transform hover:scale-105 disabled:bg-gray-500 disabled:scale-100"
            disabled={!collectionName || !description}
          >
            Analyze Collection
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
