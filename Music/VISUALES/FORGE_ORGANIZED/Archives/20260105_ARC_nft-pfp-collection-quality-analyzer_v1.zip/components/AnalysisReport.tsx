
import React from 'react';

interface AnalysisReportProps {
  report: string;
  onReset: () => void;
}

const formatMarkdown = (text: string) => {
  const adviceSectionIndex = text.indexOf('### actionable-advice');
  let mainReport = text;
  let adviceReport = '';

  if (adviceSectionIndex !== -1) {
    mainReport = text.substring(0, adviceSectionIndex);
    adviceReport = text.substring(adviceSectionIndex).replace('### actionable-advice', '### actionable-advice\n');
  }

  const parseSection = (sectionText: string) => {
    return sectionText
      .split('\n')
      .map((line, index) => {
        if (line.startsWith('### ')) {
          return <h3 key={index} className="text-2xl font-bold mt-6 mb-3 text-indigo-400">{line.substring(4)}</h3>;
        }
        if (line.startsWith('**') && line.endsWith('**')) {
           return <p key={index} className="font-bold text-gray-200 mt-2">{line.substring(2, line.length - 2)}</p>;
        }
        if (line.trim().startsWith('* ')) {
          return <li key={index} className="ml-5 list-disc text-gray-300">{line.substring(2)}</li>;
        }
        if (line.trim() === '') {
          return null; // Don't render empty lines
        }
        return <p key={index} className="text-gray-300 mb-2 leading-relaxed">{line}</p>;
      });
  };

  return { mainContent: parseSection(mainReport), adviceContent: parseSection(adviceReport) };
};

const AnalysisReport: React.FC<AnalysisReportProps> = ({ report, onReset }) => {
  const { mainContent, adviceContent } = formatMarkdown(report);

  return (
    <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 sm:p-8 animate-fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
                {mainContent}
            </div>
            <div className="lg:col-span-1 bg-gray-900/70 p-6 rounded-lg border border-indigo-700/50">
                 {adviceContent}
            </div>
        </div>
      
      <div className="text-center mt-8">
        <button
          onClick={onReset}
          className="px-6 py-2 bg-gray-600 rounded-lg font-semibold text-white hover:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-gray-500 transition-colors"
        >
          Analyze Another File
        </button>
      </div>
       <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default AnalysisReport;
