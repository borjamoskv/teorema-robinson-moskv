# Music Master – Backend Starter

**Fecha:** 2025-11-08

Tres opciones de backend para el endpoint `POST /action` que usa tu OpenAPI:
- **Vercel** (`vercel/`) – Serverless function + rewrite `/action` → `/api/action`
- **Cloudflare Worker** (`cloudflare/`) – Worker TypeScript
- **Express** (`express/`) – Server Node clásico

---

## 1) Vercel

**Estructura**: `vercel/api/action.ts`, `vercel/vercel.json` (rewrite), `vercel/package.json`

### Deploy
1. `cd vercel`
2. (Opcional) `npm i` si quieres añadir libs; no hace falta para el stub.
3. `vercel` (requiere `npm i -g vercel` y login) o conecta el repo en vercel.com.

Tras desplegar, tu dominio será algo así: `https://tu-proyecto.vercel.app`.

**OpenAPI** → `servers[0].url`: `https://tu-proyecto.vercel.app`

### Test
```bash
curl -X POST "https://tu-proyecto.vercel.app/action"   -H "Content-Type: application/json"   -d '{{"action":"make_setlist","params":{{"start_bpm":132,"end_bpm":90,"duracion_min":75,"arco":"rave→spa"}}}}'
```

---

## 2) Cloudflare Worker

**Estructura**: `cloudflare/src/worker.ts`, `cloudflare/wrangler.toml`, `cloudflare/package.json`

### Deploy
1. `cd cloudflare`
2. `npm i` (instala Wrangler)
3. `npm run deploy` (te pedirá login la primera vez)

Obtendrás una URL tipo: `https://<worker>.<subdominio>.workers.dev`  
**OpenAPI** → `servers[0].url`: esa URL.

### Test
```bash
curl -X POST "https://<worker>.<subdominio>.workers.dev/action"   -H "Content-Type: application/json"   -d '{{"action":"make_setlist","params":{{"start_bpm":132,"end_bpm":90,"duracion_min":75,"arco":"rave→spa"}}}}'
```

---

## 3) Express (Render/Railway/Server propio)

**Estructura**: `express/server.js`, `express/package.json`

### Local
```bash
cd express
npm i
npm start
# Servirá en http://localhost:8787
```

Para usarlo en **Actions** necesitas HTTPS público. Opciones:
- **Render.com** (Web Service): 
  - Build Command: `npm install`
  - Start Command: `npm start`
- **Railway.app / Fly.io / Heroku**: similar.

**OpenAPI** → `servers[0].url`: la URL HTTPS pública de tu app.

### Test
```bash
curl -X POST "https://TU-DOMINIO/action"   -H "Content-Type: application/json"   -d '{{"action":"make_setlist","params":{{"start_bpm":132,"end_bpm":90,"duracion_min":75,"arco":"rave→spa"}}}}'
```

---

## Notas

- El stub valida `action` y devuelve `{{ ok: true, result: ... }}`. Implementa la lógica real dentro de los `handlers`.
- CORS está activado (origen `*`) para facilitar pruebas con GPT Actions.
- Si prefieres `/api/action` en OpenAPI, quita el *rewrite* de Vercel y cambia `paths` a `/api/action`.

¡Dale! Si quieres lo empaqueto como **Docker** o añado logging (pino), auth (token simple) y rate-limit.
