// vercel/api/action.ts
// Vercel Serverless – endpoint POST /action (via rewrite)
// CORS + validación básica + handlers stub

const ACTIONS_CORE = [
  "make_setlist","set_arc_plot","bpm_energy_map","crate_digger","key_detect","tempo_map","groove_extractor","swing_injector","cue_points_auto","transition_suggester",
  "master_warm_club","stem_balancer","transient_sculpt","bass_consistency","kick_bass_align","stereo_field_analyzer","haas_magic","sibilance_tamer","reverb_match","spectral_space",
  "cover_art_glitch","logo_gen","sticker_pack_png","animated_loop","frames_videoclip_batch","prompt_forge_video","prompt_forge_music","glitch_poetry","silence_sculptor","persona_voice_cast",
  "mint_pack_zora","zora_stream_prep","trait_csv_builder","rarity_balancer","metadata_autofill","pfp_variations","airdrop_plan","onchain_mixdrop","press_release","track_desc_es",
  "hook_generator","thread_writer","email_pitch","bio_variations","title_shaker","tagline_lab","fan_segmenter","analytics_digest","folder_structure_builder","backup_manifest"
] as const;

type ActionName = typeof ACTIONS_CORE[number];
type RunActionRequest = { action: ActionName; params?: Record<string, any>; dryRun?: boolean };
type RunActionResponse = { ok: boolean; action?: ActionName; result?: any; logs?: string[]; error?: string };

function json(res: any, body: any, status = 200) {
  res.setHeader("Content-Type","application/json");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("Access-Control-Allow-Headers","*");
  res.setHeader("Access-Control-Allow-Methods","POST, OPTIONS");
  res.status(status).send(JSON.stringify(body));
}

function validateAction(a: string): a is ActionName {
  return (ACTIONS_CORE as readonly string[]).includes(a);
}

const handlers: Record<ActionName, (params: any)=>Promise<any>> = Object.fromEntries(
  (ACTIONS_CORE as readonly ActionName[]).map(a => [a, async (p:any)=>({ message:`Stub ejecutado: ${a}`, echo:p??{} })])
) as any;

export default async function handler(req: any, res: any) {
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return json(res, { ok:false, error:"Method not allowed" }, 405);

  try {
    const contentType = req.headers["content-type"] || "";
    if (!String(contentType).includes("application/json")) {
      return json(res, { ok:false, error:"Content-Type must be application/json" }, 415);
    }

    const bodyIn: RunActionRequest = req.body && typeof req.body === "object" ? req.body : JSON.parse(req.body || "{}");

    if (!bodyIn?.action) return json(res, { ok:false, error:"'action' requerido" }, 400);
    if (!validateAction(bodyIn.action)) return json(res, { ok:false, error:`Acción no soportada: ${bodyIn.action}` }, 400);

    const run = handlers[bodyIn.action];
    const result = bodyIn.dryRun ? { dryRun:true, accepted:true, params: bodyIn.params ?? {} } : await run(bodyIn.params ?? {});

    return json(res, { ok:true, action: bodyIn.action, result, logs:["validated params", bodyIn.dryRun?"dry-run":"executed"] }, 200);
  } catch (err:any) {
    return json(res, { ok:false, error: err?.message || String(err) }, 500);
  }
}
