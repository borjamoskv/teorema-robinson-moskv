// express/server.js
// Express server – endpoint POST /action (CORS simple)

const express = require("express");
const app = express();
app.use(express.json({ limit: "5mb" }));

// CORS
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "*");
  res.header("Access-Control-Allow-Methods", "POST, OPTIONS");
  if (req.method === "OPTIONS") return res.status(204).end();
  next();
});

const ACTIONS_CORE = [
  "make_setlist","set_arc_plot","bpm_energy_map","crate_digger","key_detect","tempo_map","groove_extractor","swing_injector","cue_points_auto","transition_suggester",
  "master_warm_club","stem_balancer","transient_sculpt","bass_consistency","kick_bass_align","stereo_field_analyzer","haas_magic","sibilance_tamer","reverb_match","spectral_space",
  "cover_art_glitch","logo_gen","sticker_pack_png","animated_loop","frames_videoclip_batch","prompt_forge_video","prompt_forge_music","glitch_poetry","silence_sculptor","persona_voice_cast",
  "mint_pack_zora","zora_stream_prep","trait_csv_builder","rarity_balancer","metadata_autofill","pfp_variations","airdrop_plan","onchain_mixdrop","press_release","track_desc_es",
  "hook_generator","thread_writer","email_pitch","bio_variations","title_shaker","tagline_lab","fan_segmenter","analytics_digest","folder_structure_builder","backup_manifest"
];

const handlers = Object.fromEntries(ACTIONS_CORE.map(a => [a, async (p) => ({ message: `Stub ejecutado: ${a}`, echo: p ?? {} })]));

function validateAction(a) {
  return ACTIONS_CORE.includes(a);
}

app.post("/action", async (req, res) => {
  try {
    const bodyIn = req.body || {};
    if (!bodyIn.action) return res.status(400).json({ ok:false, error: "'action' requerido" });
    if (!validateAction(bodyIn.action)) return res.status(400).json({ ok:false, error: `Acción no soportada: ${bodyIn.action}` });

    const result = bodyIn.dryRun ? { dryRun:true, accepted:true, params: bodyIn.params ?? {} } : await handlers[bodyIn.action](bodyIn.params ?? {});
    return res.json({ ok:true, action: bodyIn.action, result, logs:["validated params", bodyIn.dryRun ? "dry-run" : "executed"] });
  } catch (err) {
    return res.status(500).json({ ok:false, error: err?.message || String(err) });
  }
});

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`Music Master server escuchando en :${PORT}`));
